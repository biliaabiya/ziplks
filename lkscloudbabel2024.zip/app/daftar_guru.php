<?php
include_once './components/header.php';
include_once './components/table_guru.php';
include_once './components/footer.php';
?>