<?php
include_once './components/header.php';
include_once './components/table_sekolah.php';
include_once './components/footer.php';
?>