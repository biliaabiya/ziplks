<?php
include_once './components/header.php';
include_once './components/index.php';
include_once './components/footer.php';
?>